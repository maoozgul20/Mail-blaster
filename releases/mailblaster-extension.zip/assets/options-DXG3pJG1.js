import{c as o,j as e,A as t}from"./App-ftbuYb1F.js";o(document.getElementById("root")).render(e.jsx(t,{mode:"options"}));
