import{c as e,j as o,A as t}from"./App-C3l0fl5O.js";e(document.getElementById("root")).render(o.jsx(t,{mode:"popup"}));
