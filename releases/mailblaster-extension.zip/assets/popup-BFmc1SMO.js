import{c as e,j as o,A as t}from"./App-ftbuYb1F.js";e(document.getElementById("root")).render(o.jsx(t,{mode:"popup"}));
