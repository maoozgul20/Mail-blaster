import{c as o,j as e,A as t}from"./App-C3l0fl5O.js";o(document.getElementById("root")).render(e.jsx(t,{mode:"options"}));
